﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DESK_MES
{
    public partial class frmLOT : FormStyle_2
    {
        public frmLOT()
        {
            InitializeComponent();
            label1.Text = "LOT 상태 및 이력 조회";
        }
    }
}
